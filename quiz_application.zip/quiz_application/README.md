# Quiz Application

## Problem Statement
Develop a quiz application in Python with category selection, 10 questions, a timer, score calculation, and a final result.

## Assigned Feature Set
Feature Set A:
- Category selection
- 10 questions
- Timer
- Score calculation
- Final result

## Features Implemented
1. Category selection
2. Exactly 10 questions for each category
3. 60-second countdown timer
4. Automatic submission when time expires
5. Score calculation
6. Percentage calculation
7. Final result page
8. Option to take another quiz
9. Responsive basic frontend

## Technologies Used
- Python
- Flask
- HTML
- CSS
- JavaScript

## AI Tools Used
- ChatGPT

## Important AI Prompt / AI Usage
Example prompt:
"Create a beginner-friendly Flask quiz application using Python with category selection, 10 questions, a timer, score calculation and final result."

The generated code was reviewed and tested before use.

## Instructions to Run the Project

### 1. Open the project folder
Open a terminal inside the `quiz_application` folder.

### 2. Create a virtual environment
Windows:
```text
python -m venv test
```

### 3. Activate the virtual environment
Windows Command Prompt:
```text
test\Scripts\activate
```

Windows PowerShell:
```text
.\test\Scripts\Activate.ps1
```

### 4. Install Flask
```text
pip install -r requirements.txt
```

### 5. Run the application
```text
python app.py
```

### 6. Open in browser
```text
http://127.0.0.1:5000
```

## Project Structure
```text
quiz_application/
│
├── app.py
├── requirements.txt
├── README.md
│
├── templates/
│   ├── index.html
│   ├── quiz.html
│   └── result.html
│
└── static/
    └── style.css
```
